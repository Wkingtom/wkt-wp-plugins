<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package finaco
 */

get_sidebar( 'footer' );

 wp_footer(); ?>
 
 <a href="#" class="scroll-to-top show">
            <div class="tooltip-text">
                <span><?php _e('Back To Top','finaco');?></span>
            </div>
        </a>
 

 
 </div>
</div>
</body>

</html>