<?php
/**
 * The template for displaying archive pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package finaco
 */
get_header();
get_template_part('index','banner');?>
 
<section class="section-padding-70 bg-offwhite">
            <div class="container">
                <div class="row"><?php 
		
			finaco_archive_before(); 
			finaco_archive_loop(); 
			finaco_archive_after();?>
			
		</div>
		
	</div>
	
</section>
<?php get_footer();