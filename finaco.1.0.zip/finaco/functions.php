<?php
/**
 * finaco functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package finaco
*/

/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which runs
 * before the init hook. The init hook is too late for some features, such as indicating
 * support post thumbnails.
*/

/**
 * Define Constants
*/
define( 'FINACO_THEME_VERSION', '1.0' );
define( 'FINACO_THEME_DIR', trailingslashit( get_template_directory() ) );
define( 'FINACO_THEME_URI', trailingslashit( esc_url( get_template_directory_uri() ) ) );


if(!function_exists('finaco_setup')):
	function finaco_setup()
	{
		 /**
		 * Make theme available for translation.
		 * Translations can be placed in the /languages/ directory.
		 */
		load_theme_textdomain( 'finaco', FINACO_THEME_DIR . '/languages' );
		
		/**
		 * Load theme hooks
		 */
		require_once FINACO_THEME_DIR . 'inc/menu/class-finaco-bootstrap-navwalker.php';
		
		// woocommerce support
		add_theme_support( 'woocommerce' );
		
		
		/**
		 * Add default posts and comments RSS feed links to <head>.
		 */
		add_theme_support( 'automatic-feed-links' );
		
		 /**
		 * Enable support for Post Thumbnails on posts and pages.
		 *
		 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		 */
		add_theme_support( 'post-thumbnails' );
		add_image_size( 'finaco-720', 720 );
		
		/*
		 * Let WordPress manage the document title.
		 * By adding theme support, we declare that this theme does not use a
		 * hard-coded <title> tag in the document head, and expect WordPress to
		 * provide it for us.
		 */
		add_theme_support( 'title-tag' );
		
		/**
		 * Add support for two custom navigation menus.
		 */
		register_nav_menus( array(
			'primary'   => esc_html__( 'Primary Menu', 'finaco' ),
			'footer-menu'   => esc_html__( 'Footer Menu', 'finaco' ),
		) );
		
		/**
		 * Switch default core markup for search form, comment form, and comments
		 * to output valid HTML5.
		 */
		add_theme_support( 'html5', array(
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
		) );

		// Add theme support for selective refresh for widgets.
		add_theme_support( 'customize-selective-refresh-widgets' );
		
		/*
		 * This theme styles the visual editor to resemble the theme style,
		 * specifically font, colors, icons, and column width.
		 */
		add_editor_style( array( 'css/bootstrap.css', 'css/editor-style.css' ) );
		

		
	//Custom logo
		add_theme_support( 'custom-logo', array(
			'height'      => 40,
			'width'       => 175,
			'flex-height' => true,
			'flex-height' => true,
		) );
	
	// custom header Support
			$args = array(
			'default-image'		=>  get_template_directory_uri() .'/images/fun-facts.jpg',
			'width'			=> '1600',
			'height'		=> '900',
			'flex-height'		=> false,
			'flex-width'		=> false,
			'header-text'		=> true,
			'default-text-color'	=> '#143745'
		);
		add_theme_support( 'custom-header', $args );
	}
endif;
add_action('after_setup_theme','finaco_setup');


 
/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
*/
 
function finaco_content_width()
{
	$GLOBALS['content_width'] = apply_filters( 'finaco_content_width', 1170 );
}
add_action( 'after_setup_theme', 'finaco_content_width', 0 );



function finaco_scripts()
{
	wp_enqueue_style( 'boostrap-css', FINACO_THEME_URI . '/css/bootstrap.min.css' );
	wp_enqueue_style( 'animate-css', FINACO_THEME_URI . '/css/animate.css' );
	wp_enqueue_style( 'owl_carousel_min_css', FINACO_THEME_URI . '/css/owl.carousel.min.css' );
	wp_enqueue_style( 'magnific-popup-css', FINACO_THEME_URI . '/css/magnific-popup.css' );
	wp_enqueue_style( 'font-awesome', FINACO_THEME_URI . '/css/font-awesome/css/font-awesome.min.css' );
	wp_enqueue_style( 'finaco-style', get_stylesheet_uri() );
	wp_enqueue_style( 'finaco-default-css', FINACO_THEME_URI . '/css/skins/default.css' );
	
	wp_enqueue_script( 'owl_carousel_min_js', FINACO_THEME_URI . '/js/owl.carousel.min.js',array( 'jquery' ), FINACO_THEME_VERSION, true );
	
	wp_enqueue_script( 'boostrap-js', FINACO_THEME_URI . '/js/bootstrap.min.js', array( 'jquery' ), FINACO_THEME_VERSION, true );	
	wp_enqueue_script( 'boostrap-bundel-js', FINACO_THEME_URI . '/js/bootstrap.bundle.min.js', array( 'jquery' ), FINACO_THEME_VERSION, true );	
	
	wp_enqueue_script( 'jquery-magnific-popup', FINACO_THEME_URI . '/js/jquery.magnific-popup.min.js', FINACO_THEME_VERSION, true );
	
	wp_enqueue_script( 'finaco-custom-scripts', FINACO_THEME_URI . '/js/custom.js', array( 'jquery' ), FINACO_THEME_VERSION, true );
	
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'finaco_scripts' );


/**
* Add welcome page
**/
 if ( is_admin() ) {
	 $theme = wp_get_theme();
	if ( 'Finaco' == $theme->name){
 require FINACO_THEME_DIR . '/inc/admin/finaco-welcome.php';
	}
 }


require FINACO_THEME_DIR .'/inc/font/font.php';

/**
 * Sidebar additions.
*/
require FINACO_THEME_DIR . '/inc/core/functions/sidebar-function.php';
require FINACO_THEME_DIR . '/inc/core/functions/finaco_info_widget.php';
require FINACO_THEME_DIR . '/inc/core/functions/finaco_social_widget.php';




/**
 * Load Custom select control in Customizer
*/
if ( class_exists( 'WP_Customize_Control' ) ) {	
require_once get_template_directory() . '/inc/customizer/custom-controls/iconpicker-control/customize-iconpicker-control.php';
}

/**
 * Customizer settings files.
*/
require FINACO_THEME_DIR . 'inc/customizer/plugin_recommend.php';

/**
 * TGMPA
*/
require_once FINACO_THEME_DIR . '/inc/tgmpa/class-tgm-plugin-activation.php';
function finaco_register_required_plugins_function()
{
	$plugins = array(
		
		array(
			'name'      => 'Wpazure Companion',
			'slug'      => 'wpazure-companion',
			'required'  => false,
		),
		
		
		array(
			'name'      => 'Contact Form 7',
			'slug'      => 'contact-form-7',
			'required'  => false,
		),
		
		array(
			'name'      => 'WooCommerce',
			'slug'      => 'woocommerce',
			'required'  => false,
		),
				
	);	

	$config = array(
		'id'           => 'finaco',
		'default_path' => '',
		'menu'         => 'tgmpa-install-plugins',
		'has_notices'  => true,
		'dismissable'  => true,
		'dismiss_msg'  => '',
		'is_automatic' => false,
		'message'      => '',
	);

	tgmpa( $plugins, $config );
}
add_action( 'tgmpa_register', 'finaco_register_required_plugins_function' );


/**
 * Custom template tags for this theme.
*/
require FINACO_THEME_DIR . '/inc/template-tags.php';

/**
 * section functions files.
*/

require FINACO_THEME_DIR . '/inc/core/themes-hooks.php';
require FINACO_THEME_DIR . 'inc/core/functions/header-function.php';
require FINACO_THEME_DIR . 'inc/core/functions/content-function.php';
require FINACO_THEME_DIR . 'inc/core/functions/single-function.php';
require FINACO_THEME_DIR . 'inc/core/functions/archive-function.php';
require FINACO_THEME_DIR . 'inc/core/functions/footer-function.php';

require FINACO_THEME_DIR . '/inc/finaco-pro/class-finaco-get-pro-section.php';

add_action( "customize_register", "cusultera_remove_default_customize_register" );
function cusultera_remove_default_customize_register( $wp_customize ) {

 //=============================================================
 // Remove Colors, 
 // option from theme customizer     
 //=============================================================
 $wp_customize->remove_section("colors");

}

function finaco_read_more_link() {
    return '<a class="site-button site-button-primary btn-hover btn-animation" href="' . get_permalink() . '"><span class="btn-text">'. __( "Read more", "finaco" ) .'</span></a>';
}
add_filter( 'the_content_more_link', 'finaco_read_more_link' );




/**
 * Include a skip to content link at the top of the page so that users can bypass the menu.
 */
function finaco_skip_link() {
	echo '<a class="skip-link screen-reader-text" href="#site-content">' . __( 'Skip to the content', 'finaco' ) . '</a>';
}

add_action( 'wp_body_open', 'finaco_skip_link', 5 );

// Register panels, sections, settings, controls, and partials.
	add_action( 'customize_register', 'sections'  );
	function sections( $manager ) {

		// Register custom section types.
		$manager->register_section_type( 'finaco_Get_Pro_Section' );

		// Register sections.
		$manager->add_section(
			new finaco_Get_Pro_Section(
				$manager,
				'upfront_upsell',
				array(
					'pro_text' => esc_html__( 'Go To finaco pro',  'finaco' ),
					'pro_url'  => 'https://www.wpazure.com/finaco-pro/',
					'priority' => 0,
				)
			)
		);
	}

add_filter( 'get_custom_logo', 'change_logo_class' );


function change_logo_class( $html ) {

    $html = str_replace( 'navbar-brand', 'img-fluid', $html );
    //$html = str_replace( 'navbar-brand', 'img-fluid', $html );

    return $html;
}
