﻿=== Finaco ===
Contributors: wpazure
Tags: one-column, two-columns, right-sidebar, flexible-header, custom-colors, custom-menu, custom-logo, editor-style, featured-images, footer-widgets, sticky-post, threaded-comments, full-width-template, blog, e-commerc
Requires at least: 4.7
Requires PHP: 5.6
Tested up to: 6.0.1
Stable tag: 1.0
License: GNU General Public License v3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Finaco is fast, fully customizable & beautiful WordPress theme suitable for blog, personal portfolio, business website and WooCommerce store. It is very lightweight  and easy to manage theme. This is a SEO friendly theme. It has many special features and pre built templates so that it works perfectly with all page builders like Elementor, Beaver Builder, Visual Composer, SiteOrigin, Divi, etc. It has many other features like WooCommerce Ready, Responsive, RTL & Translation Ready, Regularly updated and designed. UpfronWp is fast, fully customizable and WooCommerce ready theme that you can use for building any kind of website!.  https://finaco-pro.wpazure.com/


== Description ==

Finaco is fast, fully customizable & beautiful WordPress theme suitable for blog, personal portfolio, business website and WooCommerce store. It is very lightweight  and easy to manage theme. This is a SEO friendly theme. It has many special features and pre built templates so that it works perfectly with all page builders like Elementor, Beaver Builder, Visual Composer, SiteOrigin, Divi, etc. It has many other features like WooCommerce Ready, Responsive, RTL & Translation Ready, Regularly updated and designed. UpfronWp is fast, fully customizable and WooCommerce ready theme that you can use for building any kind of website!. https://finaco-pro.wpazure.com/

== Changelog === 1.0 =* Wordpress version compatibility.= 0.3 =* Update theme uri.= 0.3 =* Removed Author uri.= 0.2 =* Removed theme uri.
= 0.1 =
* Initial Version Released.

== Resources ==
Finaco WordPress Theme, Copyright 2021 Wpazure
Finaco is distributed under the terms of the GNU GPL

Finaco bundles the following third-party resources:

* CSS bootstrap.css
	Code and documentation copyright 2011-2019 Twitter, Inc. Code released under the MIT license. Docs released under Creative Commons.	https://getbootstrap.com/

* CSS animation.css
	Copyright (c) 2018 Daniel Eden
	License: http://opensource.org/licenses/MIT

* JS bootstrap.js
	Copyright 2011-2019 The Bootstrap Authors (https://github.com/twbs/bootstrap/graphs/contributors)
	https://github.com/twbs/bootstrap/blob/master/LICENSE

* JS popper.js
	Copyright (C) Federico Zivolo 2018 
	License: http://opensource.org/licenses/MIT


* Font Awesome icons, Copyright Dave Gandy
	License: SIL Open Font License, version 1.1.
	Source: http://fontawesome.io/
	
* Customizer Pro section
	Author: Justin Tadlock
	URL:  https://github.com/justintadlock/trt-customizer-pro
	License: GPLv2 or later
	
* TGMPA
	Source:  http://tgmpluginactivation.com/
	License: GPL-2.0+
	
* Customizer Notify:
	Copyright: (c) Mikesetzer
	License: Under GNU General Public License
	Source: https://github.com/mikesetzer/origintheme/tree/master/ti-customizer-notify	
	
* Screenshot Images

 	
	Image for Banner section image
	License: CC0 Public Domain
	Source: https://pxhere.com/en/photo/1575609
	
	