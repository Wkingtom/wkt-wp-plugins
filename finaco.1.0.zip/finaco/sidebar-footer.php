<?php

finaco_footer_before();

finaco_footer();

finaco_footer_after();
