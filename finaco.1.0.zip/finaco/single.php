<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package finaco
 */

get_header();

//Banner
get_template_part('index','banner'); ?>

 <section class="section-padding-70 bg-offwhite">
            <div class="container">
                <div class="row"><?php 
			
			
			finaco_single_loop(); 
			?>
			
		</div>
	</div>
</section>
<?php get_footer();