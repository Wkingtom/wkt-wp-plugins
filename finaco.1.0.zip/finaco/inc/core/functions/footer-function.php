<?php 
/**
 * Function to get site Footer
 */
if ( ! function_exists( 'finaco_footer_markup' ) ) {

	/**
	 * Site Footer - <footer>
	 */
	function finaco_footer_markup() { ?>
	
	
	
	<footer class="main-footer with-bg" style="background-image: url(<?php echo esc_url(FINACO_THEME_URI .'images/footer/iot-technology-concept-city-transport-smart-1575603-pxhere.jpg'); ?>);">
            <div class="container position-relative">
                <div class="row">
				<?php if ( is_active_sidebar( 'footer-widget-1' ) ) : ?>
                    <div class="col-xl-3 col-md-6 col-12 mb-xl-0 mb-5 1">
                       <?php dynamic_sidebar( 'footer-widget-1' ); ?>	
                           
                    </div>
					<?php endif;?>

                    <?php if ( is_active_sidebar( 'footer-widget-2' ) ) : ?>
                    <div class="col-xl-3 col-md-6 col-12 mb-xl-0 mb-5 2">
                       <?php dynamic_sidebar( 'footer-widget-2' ); ?>	
                           
                    </div>
					<?php endif;?>

                    <?php if ( is_active_sidebar( 'footer-widget-3' ) ) : ?>
                    <div class="col-xl-3 col-md-6 col-12 mb-xl-0 mb-5 3">
                       <?php dynamic_sidebar( 'footer-widget-3' ); ?>	
                           
                    </div>
					<?php endif;?>
				<?php if ( is_active_sidebar( 'footer-widget-4' ) ) : ?>
                    <div class="col-xl-3 col-md-6 col-12 4">
                         <?php dynamic_sidebar( 'footer-widget-4' ); ?>	
                    </div>
				<?php endif;?>
                </div>
            </div>

            <!-- Copyright Section Start -->
            <section class="copyright-section">
                <div class="container position-relative">
                    <div class="row">
					
					<div class="<?php  if ( is_active_sidebar( 'footer-widget-5' ) ) { echo 'col-md-6 col-12 d-flex justify-content-md-start justify-content-center mb-md-0 mb-2';} else { echo 'col-md-12 col-12 copyright-left text-center';} ?>">
				
				
					<p>
						<a href="<?php echo esc_url( __( 'https://wordpress.org/', 'finaco' ) ); ?>">
								<?php
								/* translators: placeholder replaced with string */
								printf( esc_html__( 'Proudly powered by %s', 'finaco' ), 'WordPress' );
								?>
							</a>
							
							<?php
							/* translators: placeholder replaced with string */
							printf( esc_html__( 'Theme: %1$s by %2$s.', 'finaco' ), 'finaco', '<a href="' . esc_url( __( 'https://wpazure.com/', 'finaco' ) ) . '" rel="designer">Wpazure</a>' );
							?>	
					</p>
				</div>
				<?php
		  if ( is_active_sidebar( 'footer-widget-5' ) ) : ?>
				<div class="col-md-6 col-12 d-flex justify-content-md-end justify-content-center">
					
				
					<?php dynamic_sidebar( 'footer-widget-5' ); ?>	
				
				
				</div>
				<?php endif; 
			?>
					
                    </div>
                </div>
            </section>
            <!-- Copyright Section End -->
        </footer>

	
		<!-- FOOTER SECTION END -->
		
	<?php }

}

add_action( 'finaco_footer', 'finaco_footer_markup' );