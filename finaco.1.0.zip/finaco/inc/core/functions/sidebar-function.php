<?php
/**
 * Sidebar Function for finaco Theme
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
*/

function finaco_widgets_init(){
	register_sidebar( 
				array(
					'name'          => esc_html__( 'Sidebar', 'finaco' ),
					'id'            => 'sidebar-1',
					'description'   => esc_html__( 'Add widgets here.', 'finaco' ),
					'before_widget' => '<div id="%1$s" class="widget %2$s">',
					'after_widget'  => '</div>',
					'before_title'  => '<h4 class="widget-title">',
					'after_title'   => '</h4>',
				) 
		);
		
		
	
	register_sidebar(
				array(
					'name'          => esc_html__( 'Footer One', 'finaco' ),
					'id'            => 'footer-widget-1',
					'description'   => '',
					'before_widget' => '<div id="%1$s" class="widget %2$s">',
					'after_widget'  => '</div>',
					'before_title'  => '<h3 class="widget-title">',
					'after_title'   => '</h3>',
				)
			
		);
		
	register_sidebar(
				array(
					'name'          => esc_html__( 'Footer Two', 'finaco' ),
					'id'            => 'footer-widget-2',
					'description'   => '',
					'before_widget' => '<div id="%1$s" class="widget %2$s">',
					'after_widget'  => '</div>',
					'before_title'  => '<h3 class="widget-title">',
					'after_title'   => '</h3>',
				)
			
		);
		
	register_sidebar(
				array(
					'name'          => esc_html__( 'Footer Three', 'finaco' ),
					'id'            => 'footer-widget-3',
					'description'   => '',
					'before_widget' => '<div id="%1$s" class="widget %2$s">',
					'after_widget'  => '</div>',
					'before_title'  => '<h3 class="widget-title">',
					'after_title'   => '</h3>',
				)
			
		);
		
	register_sidebar(
				array(
					'name'          => esc_html__( 'Footer Four', 'finaco' ),
					'id'            => 'footer-widget-4',
					'description'   => '',
					'before_widget' => '<div id="%1$s" class="widget %2$s">',
					'after_widget'  => '</div>',
					'before_title'  => '<h3 class="widget-title">',
					'after_title'   => '</h3>',
				)
			
		);
		
		register_sidebar(
				array(
					'name'          => esc_html__( 'Footer Copiright section', 'finaco' ),
					'id'            => 'footer-widget-5',
					'description'   => '',
					'before_widget' => '<div id="%1$s" class="widget %2$s">',
					'after_widget'  => '</div>',
					'before_title'  => '<h3 class="widget-title">',
					'after_title'   => '</h3>',
				)
			
		);
		
		
		
	register_sidebar( 
				array(
					'name' => esc_html__('WooCommerce sidebar widget area', 'finaco' ),
					'id' => 'woocommerce',
					'description' => esc_html__( 'WooCommerce sidebar widget area', 'finaco' ),
					'before_widget' => '<div id="%1$s" class="widget %2$s">',
					'after_widget' => '</div>',
					'before_title' => '<h2 class="widget-title">',
					'after_title' => '</h2>',
				) 
	);
	
	register_sidebar(
				array(
					'name'          => esc_html__( 'Top header section left', 'finaco' ),
					'id'            => 'top-header-left',
					'description'   => '',
					'before_widget' => '<div id="%1$s" class="widget %2$s">',
					'after_widget'  => '</div>',
					'before_title'  => '<h3 class="widget-title">',
					'after_title'   => '</h3>',
				)
			
		);
		
	register_sidebar(
				array(
					'name'          => esc_html__( 'Top header section right', 'finaco' ),
					'id'            => 'top-header-right',
					'description'   => '',
					'before_widget' => '<div id="%1$s" class="widget %2$s">',
					'after_widget'  => '</div>',
					'before_title'  => '<h3 class="widget-title">',
					'after_title'   => '</h3>',
				)
			
		);
	
	
		
}
add_action( 'widgets_init', 'finaco_widgets_init' );