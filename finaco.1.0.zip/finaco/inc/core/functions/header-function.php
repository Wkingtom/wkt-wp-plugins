<?php

/**

 * Function to get site Header

 */

if ( ! function_exists( 'finaco_header_markup' ) ) {



	function finaco_header_markup() {

	

	?>

	

	

	

	 <!-- Header Section Start -->

        <header class="main-header header-style-1">

		<?php if ( is_active_sidebar( 'top-header-left' ) || is_active_sidebar( 'top-header-right' )) { ?>

            <div class="header-top">

                <div class="container">

                    <div class="row d-flex align-items-center z-index-1">

                        <div class="col">

                            <div class="top-contact">

							<?php if ( is_active_sidebar( 'top-header-left' ) ) { ?>

							<?php dynamic_sidebar( 'top-header-left'); ?>

							<?php }?>

                               

                            </div>

                        </div>

                        <div class="col d-flex justify-content-end">

						<?php if ( is_active_sidebar( 'top-header-right' ) ) { ?>

							<?php dynamic_sidebar( 'top-header-right'); ?>

							<?php }?>

                            

                        </div>

                    </div>

                </div>

            </div>

		<?php }?>

		

            <div class="menu-area">

                <div class="container">

				

				

				<nav class="navbar navbar-light navbar-expand-xl mainmenu">

				 

                          

							<?php finaco_site_branding(); ?>

							

                      

                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php esc_attr_e('Toggle navigation', 'finaco');?>">

                            <span class="fa fa-bars" aria-hidden="true"></span>

                        </button>

						<div class="collapse navbar-collapse" id="navbarSupportedContent">

											<?php

												   wp_nav_menu(

												array(

													'theme_location'  => 'primary',

													'container'  => 'nav-collapse collapse navbar-inverse-collapse',

													'menu_class' => 'navbar-nav mx-auto',

													'fallback_cb'     => 'Finaco_Bootstrap_Navwalker::fallback',

													'walker'          => new Finaco_Bootstrap_Navwalker(),

												)

											);

										?>

						</div>

					 <div class="nav-right d-xl-block d-none">

                            <ul>

                                <li class="nav-contact d-xl-inline-block d-none">

                                    <a href="#" class="trigger-search">

                                        <i class="fa fa-search" aria-hidden="true"></i>

                                    </a>

                                </li>

                                

                                

                                 <!-- Search Popup Start -->

        <div class="search-popup-wrapper">

            <div class="search-popup-content">

				

			

               <?php  get_search_form(); ?>

            </div>



            <button class="close-search"><i class="fa fa-times" aria-hidden="true"></i></button>

        </div>

        <!-- Search Popup End -->

                                

                                <li>

                                    <a href="#" class="default-button animated-button button-md bg-pink">

                                        Get a Quote

                                    </a>

                                </li>

                            </ul>

                        </div>					

										

					</nav>

				

				

                </div>

            </div>  



            <!-- <div class="menu-area">

                <div class="container">

                    <nav class="navbar navbar-light navbar-expand-xl mainmenu">

                        <a class="navbar-brand" href="#">

                            <img src="assets/images/logo.png" class="img-fluid">

                        </a>

                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">

                            <span class="fa fa-bars" aria-hidden="true"></span>

                        </button>

                        <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">

                            <ul class="navbar-nav">

                                <li class="active"><a href="#">Home <span class="sr-only">(current)</span></a></li>

                                <li><a href="#">About Us</a></li>

                                <li class="dropdown">

                                    <a class="dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Services <i class="fa fa-angle-down d-xl-none d-flex" aria-hidden="true"></i></a>

                                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown">

                                    <li><a href="#">Action</a></li>

                                    <li><a href="#">Another action</a></li>

                                    <li><a href="#">Something else here</a></li>

                                    <li class="dropdown">

                                        <a class="dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Dropdown2 <i class="fa fa-angle-down d-xl-none d-flex" aria-hidden="true"></i></a>

                                        <ul class="dropdown-menu" aria-labelledby="navbarDropdown">

                                        <li><a href="#">Action</a></li>

                                        <li><a href="#">Another action</a></li>

                                        <li><a href="#">Something else here</a></li>

                                        <li class="dropdown">

                                            <a class="dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Dropdown3 <i class="fa fa-angle-down d-xl-none d-flex" aria-hidden="true"></i></a>

                                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">

                                                <li><a href="#">Action</a></li>

                                                <li><a href="#">Another action</a></li>

                                                <li><a href="#">Something else here</a></li>

                                            </ul>

                                        </li>

                                        </ul>

                                    </li>

                                    </ul>

                                </li>

                                <li class="dropdown">

                                    <a class="dropdown-toggle" href="https://fontawesome.com/v4.7/icons/" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Team <i class="fa fa-angle-down d-xl-none d-flex" aria-hidden="true"></i></a>

                                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown">

                                        <li><a href="#">Action</a></li>

                                        <li><a href="#">Another action</a></li>

                                        <li><a href="#">Something else here</a></li>

                                    </ul>

                                </li>

                                <li class="dropdown">

                                    <a class="dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Pages <i class="fa fa-angle-down d-xl-none d-flex" aria-hidden="true"></i></a>

                                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown">

                                        <li><a href="#">Action</a></li>

                                        <li><a href="#">Another action</a></li>

                                        <li><a href="#">Something else here</a></li>

                                    </ul>

                                </li>

                                <li><a href="#">News</a></li>

                                <li><a href="#">Contact</a></li>

                            </ul>

                        </div>

                    </nav>

                </div>

            </div> -->          

        </header>

        <!-- Header Section End -->



		

		

	<?php }

} 

add_action( 'finaco_header', 'finaco_header_markup' );