<?php /**
 * Theme Hook.
 *
 * @package     finaco
 */
/**
 * Header
 */
 
function finaco_header(){
	do_action( 'finaco_header' );
}
/**
 * Before Header
 */
function finaco_header_before(){
	do_action( 'finaco_header_before' );
}
/**
 * After Header
 */
function finaco_header_after(){
	do_action( 'finaco_header_after' );
}


/**
 * Before primary content
 */
function finaco_content_loop(){
	do_action( 'finaco_content_loop' );
}

/**
 * primary content
 */
function finaco_primary_content_before(){
	do_action( 'finaco_primary_content_before' );
}



/**
 * After primary content
 */
function finaco_primary_content_after(){
	do_action( 'finaco_primary_content_after' );
}

/**
* Before archive content
*/
function finaco_archive_before(){
	do_action( 'finaco_archive_before' );
}

/**
* Archive content 
*/
function finaco_archive_loop(){
	do_action( 'finaco_archive_loop' );
}

/**
* After Archive content 
*/
function finaco_archive_after(){
	do_action( 'finaco_archive_after' );
}


/**
 * single
 */
function finaco_single_loop(){
	do_action( 'finaco_single_loop' );
}

/**
 * After single
 */
function finaco_single_after(){
	do_action( 'finaco_single_after' );
}


/**
 * Before Footer 
 */
function finaco_footer_before(){
	do_action( 'finaco_footer_before' );
}

/**
 * widget Footer 
 */
function finaco_footer(){
	do_action( 'finaco_footer' );
}

/**
 * After Footer 
 */
function finaco_footer_after(){
	do_action( 'finaco_footer_after' );
}

/**
 * Scroll to top button 
 */
function finaco_scroll_to_top(){
	do_action( 'finaco_scroll_to_top' );
}