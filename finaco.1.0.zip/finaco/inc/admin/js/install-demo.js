/**
 * Install Wpazure kit
 
 */

/* global finaco_install_demo */

'use strict';

// Activate plugin.
var finacoActivatePlugin = function( url, redirect ) {
	if ( 'undefined' === typeof( url ) || ! url ) {
		return;
	}

	var request = new Request(
		url,
		{
			method: 'GET',
			credentials: 'same-origin',
			headers: new Headers({
				'Content-Type': 'text/xml'
			})
		}
	);

	fetch( request )
		.then( function( data ) {
			location.reload();
		} )
		.catch( function( error ) {
			console.log( error );
		} );
}

// Download and Install plugin.
var finacoinstallPlugin = function() {
	var installBtn = document.querySelector( '.finaco-install-demo' );
	if ( ! installBtn ) {
		return;
	}

	installBtn.addEventListener( 'click', function( e ) {
		e.preventDefault();

		var t        = this,
			url      = t.getAttribute( 'href' ),
			slug     = t.getAttribute( 'data-slug' ),
			redirect = t.getAttribute( 'data-redirect' );

		t.innerHTML = wp.updates.l10n.installing;

		t.classList.add( 'updating-message' );
		wp.updates.installPlugin(
			{
				slug: slug,
				success: function () {
					t.innerHTML = finaco_install_demo.activating + '...';
					finacoActivatePlugin( url, redirect );
				}
			}
		);
	} );
}

// Activate plugin manual.
var finacoHandleActivate = function() {
	var activeButton = document.querySelector( '.finaco-active-now' );
	if ( ! activeButton ) {
		return;
	}

	activeButton.addEventListener( 'click', function( e ) {
		e.preventDefault();

		var t        = this,
			url      = t.getAttribute( 'href' ),
			redirect = t.getAttribute( 'data-redirect' );

		t.classList.add( 'updating-message' );
		t.innerHTML = finaco_install_demo.activating + '...';

		finacoActivatePlugin( url, redirect );
	} );
}

document.addEventListener( 'DOMContentLoaded', function() {
	finacoinstallPlugin();
	finacoHandleActivate();
} );
