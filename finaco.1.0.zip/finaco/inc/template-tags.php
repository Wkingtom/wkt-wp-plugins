<?php
/**
 * Custom template tags for this theme
 *
 * Eventually, some of the functionality here could be replaced by core features.
 *
 * @package finaco
 */

 
 
/**
 * Site branding
 */
if ( !function_exists( 'finaco_site_branding' ) ) {
	function finaco_site_branding()
	{
		if ( has_custom_logo() ) :
				the_custom_logo();
		else : ?>
			
			<?php
		
		endif;
	}
}
/**
* Blog post meta date */
 
if ( ! function_exists( 'finaco_posted_on' ) ) :
	/**
	 * Prints HTML with meta information for the current post-date/time.
	 */
	function finaco_posted_on() {
		$time_string = '<time class="" datetime="%1$s">%2$s</time>';
		$time_string2 = '<time class="" datetime="%1$s">%2$s</time>';
		if ( get_the_time( 'U' ) !== get_the_modified_time( 'U' ) ) {
			$time_string = '<time class="" datetime="%1$s">%2$s</time>';
			$time_string2 = '%2$s';
		}

		$time_string = sprintf( $time_string,
			esc_attr( get_the_date( 'c' ) ),
			esc_html( get_the_date('M') ),
			esc_attr( get_the_modified_date( 'c' ) ),
			esc_html( get_the_modified_date('M') )
		);
		$time_year = sprintf($time_string2,
			esc_attr( get_the_date( 'c' ) ),
			esc_html( get_the_date('Y') ),
			esc_attr( get_the_modified_date( 'c' ) ),
			esc_html( get_the_modified_date('Y') )
		);
		$post_date = get_the_date('j');
	

		                        
		$posted_on = '<div class="post-date"><div class="date">'. $post_date. '</div>
			                        <div class="my">'. $time_string . '<br>' .$time_year.'</div></div> ';

		echo  $posted_on ;
	}
endif;

/**
* Blog post meta post by 
*/
if ( ! function_exists( 'finaco_posted_by' ) ) :
	/**
	 * Prints HTML with meta information for the current author.
	 */
	function finaco_posted_by() {
		$get_author_id = get_the_author_meta('ID');
		$get_author_gravatar = get_avatar_url($get_author_id, array('size' => 450));
	                       
		
		$byline = sprintf(
			/* translators: %s: post author. */
			'<div class="author-name ps-2">'.
			esc_html_x( 'By %s', 'post author', 'finaco' ),
			'<a class="author" href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '">' . esc_html( get_the_author() ) . '</a> </div>'
		);

		echo ' <div class="post-author"><a href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '" class="d-block mr-3"><img src="'. esc_url($get_author_gravatar).'" class="img-fluid">
                                                </a> ' . $byline. '</div>';  // WPCS: XSS OK.
	}
endif;

/**
* Blog post featured image 
*/
if ( ! function_exists( 'finaco_post_thumbnail' ) ) :
/**
 * Displays an optional post thumbnail.
 *
 * Wraps the post thumbnail in an anchor element on index views, or a div
 * element when on single views.
 */
function finaco_post_thumbnail() {
				
	if ( post_password_required() || is_attachment() || ! has_post_thumbnail() ) {
		return;
	}
	if ( is_singular() ) :
	?>
	<div class="post-img">
		<?php the_post_thumbnail( 'finaco-720' ); ?>
	</div><!-- .post-thumbnail -->

	<?php else : ?>
	<div class="post-img">
		<a  href="<?php the_permalink(); ?>" class="class="img-fluid"" aria-hidden="true">
			<?php
				the_post_thumbnail( '', array(
					'alt' => the_title_attribute( array(
						'echo' => false,
					) ),
					'class' => 'img-fluid',
					
				) );
			?>
		</a>
	</div>

	<?php endif; // End is_singular().
}
endif;



/**
 * All categories
 */
if ( ! function_exists( 'finaco_all_categories' ) ) :
function finaco_all_categories() {
	$Separate_meta = ', ';
	$categories_list = get_the_category_list($Separate_meta);

	if ( $categories_list ) {
		echo $categories_list;
	}
}
endif;

/**
 * Get the comments
 */

if ( ! function_exists( 'finaco_get_comments_number' ) ) :
	/**
	 * Prints HTML with the comment count for the current post.
	 */
	function finaco_get_comments_number() {
		
		echo ' <i class="fa fa-comment-o" aria-hidden="true"></i>';
	comments_popup_link();
	
		
	}
endif;

if ( ! function_exists( 'finaco_get_tags' ) ) :
function finaco_get_tags(){
	
/* translators: used between list items, there is a space after the comma */
	$tag_list = get_the_tag_list();
	if ( $tag_list ) {
	echo '<li class="ce-tags"> <i class="fa fa-tags" aria-hidden="true"></i>' . $tag_list .'</li>';
	}
}
endif;