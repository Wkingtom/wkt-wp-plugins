<?php
/**
 * side bar template
 *
 * @package finaco
 */


if ( ! is_active_sidebar( 'woocommerce' ) )
{
	return;
}
?>
<div class="col-lg-4 col-12 mt-lg-0 mt-4">
	<div class="widget-area">
		
<!--Sidebar-->
<?php dynamic_sidebar( 'woocommerce' ); ?>
<!--/End of Sidebar-->
	
		
	</div>
	
</div>