<?php
$background_image = get_theme_support( 'custom-header', 'default-image' );

if ( has_header_image() ) {
  $background_image = get_header_image();
}
?>

<!-- Breadcrumb Section Start -->
        <div class="breadcrumb-section">
           <div class="banner-overlay" style="background: rgba(0, 0, 0, 0.4) url(<?php echo FINACO_THEME_URI; ?>/images/slide-dot.png)"></div>
            <div class="slider-image" style="background-image: url(<?php echo esc_url( $background_image ); ?>);"></div>
            <div class="container">
                <div class="row">
                    <div class="col-12 d-flex justify-content-center align-items-center">
                        <div class="breadcrumb-title text-center position-relative">
                          <?php 
      						if ( class_exists( 'WooCommerce' ) ) {
							if ( is_shop() ) {
								echo '<h2>';
									woocommerce_page_title();
								echo '</h2>';
							}
							elseif(is_cart() || is_checkout()) {
									
									the_title(  '<h2>', '</h2>' );	
								}
							else { 
						
								the_title(  '<h2>', '</h2>' ); 
							} 
							} ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Breadcrumb Section End -->