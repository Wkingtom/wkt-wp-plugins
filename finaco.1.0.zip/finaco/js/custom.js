jQuery(document).ready(function() {

	// Toggle Mobile Menu
	jQuery('.navbar-nav li.dropdown button').on('click', function() {
        var $subMenu = jQuery(this).next(".dropdown-menu");
        $subMenu.slideToggle("fast");

        jQuery(this).children("i").toggleClass('fa-angle-up fa-angle-down');

        jQuery(this).parent().parents('li.nav-item.dropdown').on('hidden.bs.dropdown', function(){
            //jQuery('.dropdown-submenu .show').removeClass("show");
        });
        return false;
    });


    // 04 - KEYBOARD ACCESSIBLE MENU ON TAB KEY START
    jQuery('.mainmenu li a').focus( function () {
        jQuery(this).siblings('.dropdown-menu').addClass('focused');
    }).blur(function(){
        jQuery(this).siblings('.dropdown-menu').removeClass('focused');
    });
    //Sub Menu
    jQuery('.mainmenu li a').focus( function () {
        jQuery(this).parents('.dropdown-menu').addClass('focused');
    }).blur(function(){
        jQuery(this).parents('.dropdown-menu').removeClass('focused');
    });

    // close menu on focus on tab and mobile
    jQuery('.mainmenu .navbar-nav > li').last().focusout(function(){
        jQuery(this).parents(".navbar-collapse").removeClass("show");
    })
	
	
	// Magnific Popup Gallery Function
	jQuery('.popup-gallery').magnificPopup({
		delegate: '.modal-icon a',
		type: 'image',
		tLoading: 'Loading image #%curr%...',
		mainClass: 'mfp-img-mobile',
		gallery: {
			enabled: true,
			navigateByImgClick: true,
			preload: [0,1] // Will preload 0 - before current, and 1 after the current image
		},
		// image: {
		// 	tError: '<a href="%url%">The image #%curr%</a> could not be loaded.',
		// 	titleSrc: function(item) {
		// 		return item.el.attr('title') + '<small>by Marsel Van Oosten</small>';
		// 	}
		// }
	});

	// Testimonials 2 Slider Function
	jQuery('.owl-carousel').owlCarousel({
	    loop:true,
	    nav:true,
	    dots: true,
	    autoPlay: 2000,
	    // navText : ["<i class='fa fa-long-arrow-left' aria-hidden='true'></i>","<i class='fa fa-long-arrow-right' aria-hidden='true'></i>"],
	    responsive:{
	        0:{
	            items:1
	        }
	    }
	});
	
	// Testimonials 2 Slider Function
	jQuery('.testimonials-2 .owl-carousel').owlCarousel({
	    loop:false,
	    margin:30,
	    nav:false,
	    dots: false,
	    center: false,
	    navText : ["<i class='fa fa-long-arrow-left' aria-hidden='true'></i>","<i class='fa fa-long-arrow-right' aria-hidden='true'></i>"],
	    responsive:{
	        0:{
	            items:1
	        },
	        600:{
	            items:2
	        },
	        1000:{
	            items:3
	        }
	    }
	});
	
	jQuery(".trigger-search").click(function(){
		jQuery("body").addClass("popup-active");
	})
	jQuery(".close-search").on('click', function() {
		jQuery("body").removeClass("popup-active");
	})
	
});