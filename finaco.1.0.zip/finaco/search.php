<?php
/**
 * The template for displaying search results pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#search-result
 *
 * @package finaco
 */

get_header();

$background_image = get_theme_support( 'custom-header', 'default-image' );

if ( has_header_image() ) {
  $background_image = get_header_image();
}
?>

<!-- Breadcrumb Section Start -->
        <div class="breadcrumb-section">
            <div class="banner-overlay" style="background: rgba(0, 0, 0, 0.4) url(<?php echo FINACO_THEME_URI; ?>/images/slide-dot.png)"></div>
            <div class="slider-image" style="background-image: url(<?php echo esc_url( $background_image ); ?>);"></div>
            <div class="container">
                <div class="row">
                    <div class="col-12 d-flex justify-content-center align-items-center">
                        <div class="breadcrumb-title text-center position-relative">
                            <h2>
                                <?php
					/* translators: %s: search query. */
					printf( esc_html__( 'Search Results for: %s', 'finaco' ), '<span>' . get_search_query() . '</span>' );?>
                            </h2>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>	

<section class="section-padding-70 bg-offwhite">

	<div class="container">
	
		<div class="row">
			<?php $BlogLayout = get_theme_mod('blog_layout','right_sidebar');?>
			<div class="<?php if($BlogLayout=='full_width'){ echo 'col-lg-12'; } else { echo 'col-lg-8'; } ?> col-12">
				<?php if ( have_posts() ) 
				{
					
					/* Start the Loop */
					while ( have_posts() ) : the_post();
					
						get_template_part( 'template-parts/content','');
					endwhile;
					the_posts_pagination( array(
						'prev_text'          => '<i class="fa fa-angle-double-left"></i>',
						'next_text'          => '<i class="fa fa-angle-double-right"></i>'
					) );
				}
				else
				{
					get_template_part( 'template-parts/content', 'none' );
							
				}
				?>
			</div>
			<?php if($BlogLayout == 'right_sidebar'){ get_sidebar();} ?>
		</div>
	</div>
</section>
<?php get_footer();