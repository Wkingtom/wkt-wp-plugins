<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package finaco
 */
?>

<div id="post-<?php the_ID(); ?>" <?php post_class('post-wrapper');?>>

	
		<?php finaco_post_thumbnail();?>
		<div class="post-content">
			<div class="post-meta">
				<div class="post-author">
					
					<?php echo finaco_posted_by();?>
				</div>
				<div class="post-date">
					<?php finaco_posted_on();?>
				</div>
			</div>
			<h2 class="post-title">
				<a href="<?php the_permalink(); ?>"><?php the_title();?></a>
			</h2>
			<div class="entry-content">   
				<?php the_content(__('Read More','finaco')); ?>
			</div>
			<!--<a href="#" class="read-more default-color-1">Read more</a>-->
		</div>

</div>

