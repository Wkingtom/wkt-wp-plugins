<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package finaco
 */

get_header();
$background_image = get_theme_support( 'custom-header', 'default-image' );
if ( has_header_image() ) {
  $background_image = get_header_image(); 
  }

?>


 <div class="breadcrumb-section">
            <div class="banner-overlay" style="background: rgba(0, 0, 0, 0.4) url(<?php echo FINACO_THEME_URI; ?>/images/slide-dot.png)"></div>
            <div class="slider-image" style="background-image: url(<?php echo esc_url( $background_image ); ?>);"></div>
            <div class="container">
                <div class="row">
                    <div class="col-12 d-flex justify-content-center align-items-center">
                        <div class="breadcrumb-title text-center position-relative">
                            <h2>
                                <?php esc_html_e('404 Not Found','finaco');?>
                            </h2>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>	

		
		 <!-- Career Section Start -->
        <section class="section-padding-70 bg-white page-404">
            <div class="container">
                <div class="row">
                    <div class="col-12 text-center">
                        <h3><?php esc_html_e('404','finaco');?></h3>
                        <h4><?php esc_html_e('Sorry, Page not found','finaco');?></h4>
                        
                        <a href="<?php echo esc_url(home_url());?>" class="default-button animated-button button-lg bg-pink">
                            <?php esc_html_e('Back to Home','finaco');?>
                        </a>
                    </div>
                </div>
            </div>
        </section>
		
	</div>
	<!-- CONTENT AREA END -->
<?php
get_footer();
?>