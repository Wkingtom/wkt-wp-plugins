<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package finaco
 */
get_header();
//get_template_part('index','banner');
$background_image = get_theme_support( 'custom-header', 'default-image' );

if ( has_header_image() ) {
  $background_image = get_header_image();
}
?>

<!-- Breadcrumb Section Start -->
        <div class="breadcrumb-section">
           <div class="banner-overlay" style="background: rgba(0, 0, 0, 0.4) url(<?php echo FINACO_THEME_URI; ?>/images/slide-dot.png)"></div>
            <div class="slider-image" style="background-image: url(<?php echo esc_url( $background_image ); ?>);"></div>
            <div class="container">
                <div class="row">
                    <div class="col-12 d-flex justify-content-center align-items-center">
                        <div class="breadcrumb-title text-center position-relative">
                         <h2>
							<?php $our_title = get_the_title( get_option('page_for_posts', true) );
										echo esc_html($our_title); ?>
						</h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Breadcrumb Section End -->

<!-- Latest News Section Start -->
        <section class="section-padding-70 bg-offwhite">
            <div class="container">
                <div class="row">
                    <?php finaco_content_loop(); ?>
                </div>
            </div>
        </section>
        <!-- Latest News Section End -->
<?php get_footer();
