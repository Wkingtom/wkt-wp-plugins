<?php defined( 'ABSPATH' ) or exit; ?>

<div style="margin: 12px 0;">
	<p>
		<strong><a href="https://wordpress.org/plugins/mailchimp-for-wp/">MC4WP: Mailchimp for WordPress</a></strong><br />
		The #1 Mailchimp plugin for WordPress.
	</p>
</div>

<div style="margin: 12px 0;">
	<p>
		<strong><a href="https://wordpress.org/plugins/koko-analytics/">Koko Analytics</a></strong><br />
		Privacy-friendly analytics plugin that does not use any external services.
	</p>
</div>

<div style="margin: 12px 0;">
	<p>
		<strong><a href="https://wordpress.org/plugins/html-forms/">HTML Forms</a></strong><br />
		Flexible multi-purpose forms where you have full control over the HTML.
	</p>
</div>


