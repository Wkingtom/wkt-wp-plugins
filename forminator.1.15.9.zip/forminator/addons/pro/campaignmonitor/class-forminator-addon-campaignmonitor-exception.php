<?php

/**
 * Class Forminator_Addon_Campaignmonitor_Exception
 * Not Required but encouraged
 *
 * @since 1.0 Campaignmonitor Addon
 */
class Forminator_Addon_Campaignmonitor_Exception extends Exception {

}
