<?php

/**
 * Class Forminator_Addon_Googlesheet_Exception
 * Not Required but encouraged
 *
 * @since 1.0 Google Sheets Addon
 */
class Forminator_Addon_Googlesheet_Exception extends Exception {

}
