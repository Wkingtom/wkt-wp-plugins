<?php
defined( 'ABSPATH' ) OR exit;

add_action('admin_menu', 'free_vehicle_data_plugin_setup_menu');
add_action('admin_head', 'free_vehicle_data_uk_admin_styles');



//admin page style
function free_vehicle_data_uk_admin_styles() {
wp_enqueue_style( 'free_vehicle_data_admin', plugins_url( '/assets/css/admin.css', __FILE__ ) );
}
 
function free_vehicle_data_plugin_setup_menu(){
add_menu_page( 'Free Vehicle Data UK', 'FVD UK', 'manage_options', 'free-vehicle-data-uk', 'free_vehicle_data_admin_area', 'dashicons-car');
}


//main admin page and setup.. 
function free_vehicle_data_admin_area(){
//$DisabledAPIfile = plugin_dir_path(__FILE__) . 'DisableEndpoint.txt';
//$CreditUsFile = plugin_dir_path(__FILE__) . 'credit.txt';

register_setting( 'FVDUKDisableEndPoint', 'FVDUKDisableEndPoint' );
register_setting( 'FVDUKCreditUs', 'FVDUKCreditUs' );	

//bugfix for after upgrade of old ver to new;
	if (get_option( 'FVDUKDisableEndPoint' ) == false){
	add_option( 'FVDUKDisableEndPoint', 'yes' );//disable endpoint until signup (avoid errors)
	}
	
	if (get_option( 'FVDUKCreditUs' ) == false){
	add_option( 'FVDUKCreditUs', 'no' );//Set credit us option
	}
	
	if (get_option( 'FVDUKCreditLink' ) == false){
	$selectone = array("https://www.rapidcarcheck.co.uk/", "https://www.rapidcarcheck.co.uk/developer-api/");	
	$kxx = array_rand($selectone);
	$vxx = $selectone[$kxx];
	add_option( 'FVDUKCreditLink', $vxx );//Set credit us option
	}


if (isset($_GET["clearapi"])){
update_option("FVDUKDisableEndPoint", "yes");	
}


$CreditUsStats = get_option('FVDUKCreditUs');
$DisableAPIStats = get_option('FVDUKDisableEndPoint');


if ($CreditUsStats == 'no'){
$CurrentSupporter = 'no';	
}else{
$CurrentSupporter = 'yes';		
}

////end of settings




// FUNCTION TO DELETE IMAGE CACHE
if (isset($_POST['deleteimagecache'])) {
	
$imagefiles = glob(plugin_dir_path(__FILE__) . 'assets/vehicleimages/*');
$imageremovalcounter = '0';
foreach ($imagefiles as $imagefile) {
    if (is_file($imagefile)) {
		unlink($imagefile);
		++$imageremovalcounter;
}
}

echo '<div class="notice notice-success is-dismissible">
        <p><strong>Free Vehicle Data UK:</strong><br>' . $imageremovalcounter . ' Local image cache files have been deleted!</p>
    </div>';	
}

// FUNCTION TO WIPE SEACH LogFile
if (isset($_POST['deletesearchlog'])) {
unlink(plugin_dir_path(__FILE__) . 'assets/log.txt');

echo '<div class="notice notice-success is-dismissible">
        <p><strong>Free Vehicle Data UK:</strong><br>Vehicle search log was deleted!</p>
    </div>';	
}


// demo page creation..
if (isset($_POST['demopageimport'])) {

//import 2 column layout demo	
$twocolumnfile = plugin_dir_path(__FILE__) . 'templates/2-col-layout.php';	
$demo_content_2_column_layout = fopen($twocolumnfile, "r") or die("");
$twocoldemo = fread($demo_content_2_column_layout,filesize($twocolumnfile));
fclose($demo_content_2_column_layout);

$my_demo_post = 
[
'post_title'	=> 'Two Column FVD Demo',
'post_content'	=> $twocoldemo,
'post_status'	=> 'publish',
'post_type'		=> 'page'
];

$infopage_id_page = wp_insert_post( $my_demo_post );

//import one column layout demo
$onecolumnfile = plugin_dir_path(__FILE__) . 'templates/1-col-layout.php';	
$demo_content_1_column_layout = fopen($onecolumnfile, "r") or die("");
$onecoldemo = fread($demo_content_1_column_layout,filesize($onecolumnfile));
fclose($demo_content_1_column_layout);

$one_col_page = 
[
'post_title'	=> 'One Column FVD Demo',
'post_content'	=> $onecoldemo,
'post_status'	=> 'publish',
'post_type'		=> 'page'
];

$one_col_pageid = wp_insert_post( $one_col_page );

//import two column with alt css layout demo
$twocolumnfilealt = plugin_dir_path(__FILE__) . 'templates/2-col-layout-alt.php';	
$demo_content_2_column_layoutalt = fopen($twocolumnfilealt, "r") or die("");
$twocoldemoalt = fread($demo_content_2_column_layoutalt,filesize($twocolumnfilealt));
fclose($demo_content_2_column_layoutalt);

$two_col_pagealt = 
[
'post_title'	=> 'Two Column ALT FVD Demo',
'post_content'	=> $twocoldemoalt,
'post_status'	=> 'publish',
'post_type'		=> 'page'
];

$two_column_alt_demo = wp_insert_post( $two_col_pagealt );

//import two column with alt css layout demo (no man logo)
$twocolumnfilealt1 = plugin_dir_path(__FILE__) . 'templates/2-col-layout-alt-img.php';	
$demo_content_2_column_layoutalt1 = fopen($twocolumnfilealt1, "r") or die("");
$twocoldemoalt = fread($demo_content_2_column_layoutalt1,filesize($twocolumnfilealt1));
fclose($demo_content_2_column_layoutalt1);

$two_col_pagealt1 = 
[
'post_title'	=> 'Two Column ALT FVD Demo ALT IMG',
'post_content'	=> $twocoldemoalt,
'post_status'	=> 'publish',
'post_type'		=> 'page'
];

$two_column_alt_demo1 = wp_insert_post( $two_col_pagealt1 );


echo '<div class="notice notice-success is-dismissible">
        <p><strong>Free Vehicle Data UK:</strong><br>Your demo pages have been imported, Click through the demo pages below to see which one best matches your needs!
		<br><br>
		<h3>2 Column Demo Pages Imported:</h3>
		<strong>[Plain] Two Column Demo Page Created!</strong><br> >> <a href="'.get_permalink( $infopage_id_page ). '?Reg=FY60KGG' . '" target="_blank">View Two Column Plain Demo Page</a> - Vehicle Search Box ShortCode:<strong> [fvd_searchbox page=' . get_permalink( $infopage_id_page ) . ']</strong>	
		<br><br>
		<strong>[ALT] Two Column Demo Page Created!</strong><br> >> <a href="'.get_permalink( $two_column_alt_demo ). '?Reg=FY60KGG' . '" target="_blank">View Two Column ALT Demo Page</a>	- Vehicle Search Box ShortCode:<strong> [fvd_searchbox page=' . get_permalink( $two_column_alt_demo ) . ']</strong>
		<br><br>
		<strong>[ALT V2] Two Column Demo Page Created!</strong><br> >> <a href="'.get_permalink( $two_column_alt_demo1 ). '?Reg=FY60KGG' . '" target="_blank">View Two Column ALT V2 Demo Page</a> - Vehicle Search Box ShortCode:<strong> [fvd_searchbox page=' . get_permalink( $two_column_alt_demo1 ) . ']</strong> 
		<br><br><h3>1 Column Demo Pages Imported:</h3>	
		<strong>One Column Demo Page Created!</strong><br> >> <a href="'.get_permalink( $one_col_pageid ). '?Reg=FY60KGG' . '" target="_blank">View One Column Demo Page</a> - Vehicle Search Box ShortCode:<strong> [fvd_searchbox page=' . get_permalink( $one_col_pageid ) . ']</strong>
		</p>
    </div>';


}

// switching API packages
if (isset($_POST['credit'])) {
if ($_POST['credit'] == 'yes'){
$json_api_upgrade_req = json_decode(wp_remote_retrieve_body(wp_remote_get( 'https://www.rapidcarcheck.co.uk/FreeAccess/RequestsChange.php?auth=LeCc0xMsd00fnsMF345o3&package=gold&site=' . '&site=' . get_option( 'siteurl' ))), true);
echo '<div class="notice notice-success is-dismissible">
        <p><strong>Free Vehicle Data UK:</strong> You have upgraded to Gold API access - Refresh this page to view gold menu.</strong>
		</p>
    </div>';
update_option("FVDUKCreditUs", "yes");
$CurrentSupporter = 'yes';
}else{
//file_put_contents($CreditUsFile, 'thanks');
update_option("UTMCCreditUs", "no");
$CurrentSupporter = 'no';
$json_api_upgrade_req = json_decode(wp_remote_retrieve_body(wp_remote_get( 'https://www.rapidcarcheck.co.uk/FreeAccess/RequestsChange.php?auth=LeCc0xMsd00fnsMF345o3&package=bronze&site=' . '&site=' . get_option( 'siteurl' ))), true);
echo '<div class="notice notice-success is-dismissible">
        <p><strong>Free Vehicle Data UK:</strong> You have downgraded to Bronze API access.</strong>
		</p>
    </div>';
}	
}

// API access status check
$json_api_usage = json_decode(wp_remote_retrieve_body(wp_remote_get( 'https://www.rapidcarcheck.co.uk/FreeAccess/Requests.php?auth=LeCc0xMsd00fnsMF345o3&site=' . '&site=' . get_option( 'siteurl' ))), true);

if ($DisableAPIStats == 'yes') {
if (isset(($json_api_usage["APIAccess"]))){
update_option( 'FVDUKDisableEndPoint', 'no' );
}
}


//API limit and package check/sync [Plugin Update Bug Fix], check API server package and auto sync
if (isset(($json_api_usage["Limit"]))){
if ($json_api_usage["Limit"] == '20'){

//if (file_exists($CreditUsFile)) {
if ($CreditUsStats == 'no'){	
// do nothing, API and WP backend match
}else{
// SYNC with API to downgrade to bronze [ to match both API and backend stats ].
update_option("FVDUKCreditUs", "no");
$CurrentSupporter = 'no';	
}
}else{
// server set to gold API [automatically upgrade in WP backend]
update_option("FVDUKCreditUs", "yes");
$CurrentSupporter = 'yes';

	
}
}


//if (file_exists($DisabledAPIfile)) {
if ($DisableAPIStats == 'yes') {	
	// sign up return url;
	$AdminReturnURLAfterSignup = get_admin_url( null, null, null ) . 'admin.php?page=free-vehicle-data-uk';

if (isset($_GET['first'])) {

$AdminReturnURLAfterSignup12 = get_admin_url( null, null, null ) . 'admin.php?page=free-vehicle-data-uk';

	
	echo '<h1 class="fvduk-title">Free Vehicle Data UK</h1><small><i>by RapidCarCheck.co.uk</i></small>';
	echo '<h3>Thank you for signing up to the free API access!</h3>';
	echo '<div style="height:5px" aria-hidden="true" class="admin-spacer"></div>';
	echo '<p class="backend-font-heavy">You have signed up! Click the button below to access your admin backend</p>';
	echo '<div style="height:12px" aria-hidden="true" class="admin-spacer"></div>';	
	echo '<div class="gen_button_sign"><a class="sign-up-button1" href="'.$AdminReturnURLAfterSignup12.'"><b>ACCESS ADMIN BACKEND NOW!</b></a></div>';
	echo '<div style="height:12px" aria-hidden="true" class="admin-spacer"></div>';	

	
}else{

	echo '<h1 class="fvduk-title">Free Vehicle Data UK</h1><small><i>by RapidCarCheck.co.uk</i></small>';
	echo '<h3>Thank you for installing Free Vehicle Data UK Plugin!</h3>';
	echo '<div style="height:5px" aria-hidden="true" class="admin-spacer"></div>';
	echo '<p class="backend-font-heavy">To activate plugin/API endpoint sign-up free below (instant):</p>';
	echo '<div style="height:12px" aria-hidden="true" class="admin-spacer"></div>';
	echo '<div class="gen_button_sign"><a class="sign-up-button1" href="https://www.rapidcarcheck.co.uk/free-api-access/?site=' . get_option( 'siteurl' ) . '&return=' . $AdminReturnURLAfterSignup . '" target="_blank"><b>SIGN UP FREE NOW!</b></a></div>';
	echo '<div style="height:12px" aria-hidden="true" class="admin-spacer"></div>';
	echo '<p class="backend-font-heavy">Why Do i Need to Sign Up?</p>';
	echo '<p class="backend-font-light">Sign up takes less than 30 seconds and only requires an email address, we require sign up to keep things fair and avoid abuse of the free API service.</p>';
	//echo '<p class="backend-font-light">Once sign up is complete it can take up-to 2 hours for approval, contact support for faster approval: enquiries@rapidcarcheck.co.uk.</p>';
	echo '<div style="height:12px" aria-hidden="true" class="admin-spacer"></div>';
	//echo '<p class="backend-font-heavy">Already Signed Up?</p>';
	//echo '<p class="backend-font-light">Please allow up-to 2 hours for plugin activation, if you are still seeing this screen after 2 hours contact support for further assistance: enquiries@rapidcarcheck.co.uk</p>';
	
}

}else{
	echo '<h1 class="fvduk-title">Free Vehicle Data UK</h1><small><i>by RapidCarCheck.co.uk</i></small>';
//	if (file_exists($CreditUsFile)) {
//	$CurrentSupporter = 'no';
//	}else{
//	$CurrentSupporter = 'yes';
//	}
	echo '<div style="height:32px" aria-hidden="true" class="admin-spacer"></div>';

	//API usage based on API level
	if ($CurrentSupporter == 'yes'){
	echo '<p class="backend-font-heavy-big"><img src="' . plugin_dir_url(__FILE__) . '/assets/images/gold-star.png"> Daily API Usage</p>';
	}else{
	echo '<p class="backend-font-heavy-big"><img src="' . plugin_dir_url(__FILE__) . '/assets/images/bronze-star.png"> Daily API Usage</p>';	
	}

	echo '<p class="backend-api-stats">Usage statistics for: <strong>' . get_option( 'siteurl' ) . '</strong></p>';
	//API package
	if ($CurrentSupporter == 'yes'){
	echo '<p class="backend-api-stats">API package: <strong>Gold</strong></p>';		
	}else{
	echo '<p class="backend-api-stats">API package: <strong>Bronze</strong></p>';		
	}
	echo '<p class="backend-api-stats">Lookups made today: <strong>' . ($json_api_usage["RequestsMade"]) . ' / ' . ($json_api_usage["Limit"]) . '</strong></p>';
	echo '<p class="backend-api-stats">Lookups remaining today: <strong>' . ($json_api_usage["RequestsLeft"]) . '</strong></p>';
	
	
	
	if ($CurrentSupporter == 'yes'){
	echo '<div style="height:2px" aria-hidden="true" class="admin-spacer"></div>';
	echo '<p class="backend-api-stats-small">Request bigger limit, email us: <strong>enquiries@rapidcarcheck.co.uk</strong></p>';
	
	echo '<div style="height:22px" aria-hidden="true" class="admin-spacer"></div>';
	echo '<p class="backend-font-heavy-big"><img src="' . plugin_dir_url(__FILE__) . '/assets/images/crown.png" height="22" width="22"> API Status</p>';

	echo '<p class="backend-api-stats">System status: <strong>' . ($json_api_usage["SystemStatus"]) . '</strong></p>';
	echo '<p class="backend-api-stats">Planned maintainance: <strong>' . ($json_api_usage["ExpectedDownTime"]) . '</strong></p>';
	if (isset(($json_api_usage["GoldUserMessage"]))){
	echo '<p class="backend-api-stats">Message: <strong>' . ($json_api_usage["GoldUserMessage"]) . '</strong></p>';
	}
	
	}
	
	
	
	echo '<div style="height:32px" aria-hidden="true" class="admin-spacer"></div>';
	if ($CurrentSupporter == 'yes') {
	echo '<h2>Last 100 Vehicle Searches</h2>';
	
	//LOG FILE OUTPUT:
	$LogFile = plugin_dir_path(__FILE__) . 'assets/log.txt';
	
	if (file_exists($LogFile)){
	
	$fileforlog = file($LogFile);
	$xlogcount = count($fileforlog);	
	$searchfilesize = file($LogFile, FILE_IGNORE_NEW_LINES);
	$limitsearch = 100;
	
	echo '<textarea id="searchlog" class="backendsearchfvd" class="box" rows="10">';
	//return log file..
	foreach($searchfilesize as $searchfilesize){
	if ($limitsearch <=0){
	}else{
	--$limitsearch;	
	--$xlogcount;
	echo $fileforlog[$xlogcount];	
	}
	}
	echo '</textarea>';	
	echo '<br>To view all ' . count($fileforlog) . ' search records, <a href="' . plugin_dir_url(__FILE__) . 'assets/log.txt" target="_blank">View the full search log now</a>';
	echo '<div style="height:32px" aria-hidden="true" class="admin-spacer"></div>';
	}else{
	echo 'Search log will appear here once first search is made!';
	echo '<div style="height:32px" aria-hidden="true" class="admin-spacer"></div>';	
	}
	}
	}
	
//if (file_exists($DisabledAPIfile)) {
if ($DisableAPIStats == 'yes') {
}else{
if ($CurrentSupporter == 'yes'){

	
// offer downgrade to 50 option
echo '<div style="height:22px" aria-hidden="true" class="admin-spacer"></div>';
echo '<p class="backend-font-heavy-big"><img src="' . plugin_dir_url(__FILE__) . '/assets/images/gold-star.png"> Gold API Access</p>';
echo '<p class="clear-font-text">You have gold API access which includes:</p>';
echo '<div style="height:12px" aria-hidden="true" class="admin-spacer"></div>';
echo '<p class="clear-font-text"><img src="' . plugin_dir_url(__FILE__) . '/assets/images/gold-star.png" height="16" width="16"> 500 free vehicle lookups a day.</p>';
echo '<p class="clear-font-text"><img src="' . plugin_dir_url(__FILE__) . '/assets/images/gold-star.png" height="16" width="16"> More vehicle data: BHP, Top Speed, 0-60 MPH, Vehicle Type, Body Style, Insurance Group.</p>';
echo '<p class="clear-font-text"><img src="' . plugin_dir_url(__FILE__) . '/assets/images/gold-star.png" height="16" width="16"> Vehicle search logs.</p>';
echo '<p class="clear-font-text"><img src="' . plugin_dir_url(__FILE__) . '/assets/images/gold-star.png" height="16" width="16"> Priority email support (enquiries@rapidcarcheck.co.uk).</p>';
echo '<div style="height:10px" aria-hidden="true" class="admin-spacer"></div>';

echo '<form id="creditlink" method="POST" action="">
	<input name="credit" id="credit" type="hidden" value="no">
    <div class="gen_button_sign"><button type="submit" class="downgrade_fvd_button" id="Reg">DOWNGRADE TO BRONZE</button></div></form>';
echo '<p class="backend-font-light">Please think carefully before downgrading, if you downgrade to bronze you will have a lower daily lookup limit, no search log feature, no downtime warnings or notice and no priority email support.</p>';
echo '<p class="backend-font-light">We really appreciate and need your support; all we ask is you credit us and this is what keeps us working on and improving our free plugins (thanks for your support).</p>';

}else{
// offer upgrade to 500 option	
echo '<p class="backend-font-heavy-big"><img src="' . plugin_dir_url(__FILE__) . '/assets/images/bronze-star.png"> Bronze API Access</p>';
echo '<p class="clear-font-text">You have bronze API access which includes ('.($json_api_usage["Limit"]).' free vehicle lookups a day).</p>';
echo '<div style="height:12px" aria-hidden="true" class="admin-spacer"></div>';
echo '<p class="clear-font-text"><strong>Upgrade to FREE gold access now:</strong></p>';
echo '<p class="clear-font-text"><img src="' . plugin_dir_url(__FILE__) . '/assets/images/gold-star.png" height="16" width="16"> <strike>20</strike> 500 free vehicle lookups a day.</p>';
echo '<p class="clear-font-text"><img src="' . plugin_dir_url(__FILE__) . '/assets/images/gold-star.png" height="16" width="16"> More free vehicle data: BHP, Top Speed, 0-60 MPH, Vehicle Type, Body Style, Insurance Group.</p>';
echo '<p class="clear-font-text"><img src="' . plugin_dir_url(__FILE__) . '/assets/images/gold-star.png" height="16" width="16"> Backend search log of last 100 vehicle searches.</p>';
echo '<p class="clear-font-text"><img src="' . plugin_dir_url(__FILE__) . '/assets/images/gold-star.png" height="16" width="16"> API status and maintainance alerts.</p>';
echo '<p class="clear-font-text"><img src="' . plugin_dir_url(__FILE__) . '/assets/images/gold-star.png" height="16" width="16"> Instant upgrade with no waiting.</p>';
echo '<p class="clear-font-text"><img src="' . plugin_dir_url(__FILE__) . '/assets/images/gold-star.png" height="16" width="16"> No payment or further details required.</p>';
echo '<p class="clear-font-text"><img src="' . plugin_dir_url(__FILE__) . '/assets/images/gold-star.png" height="16" width="16"> Priority email support.</p>';
echo '<div style="height:10px" aria-hidden="true" class="admin-spacer"></div>';

echo '<form id="creditlink" method="POST" action="">
	<input name="credit" id="credit" type="hidden" value="yes">
    <div class="gen_button_sign"><button type="submit" class="upgrade_fvd_button" id="Reg">UPGRADE TO GOLD API [FREE / INSTANT]</button></div></form>';
	
echo '<p class="backend-font-light">We offer free gold API access to users who show us their support by adding a powered by rapid car check link, this link is automatically added under the vehicle search box when you upgrade.</p>';
echo '<p class="backend-font-light">We have spent many hours making this free and easy to use plugin and would really appreciate your support.</p>';


}
}	

//if (file_exists($DisabledAPIfile)) {
if ($DisableAPIStats == 'yes') {	
}else{
//vehicle data to form
echo '<div style="height:12px" aria-hidden="true" class="admin-spacer"></div>';
echo '<p class="backend-font-heavy-big"><img src="' . plugin_dir_url(__FILE__) . '/assets/images/gold-star.png"> Need a Custom Solution?</p>';
echo '<p class="clear-font-text">We have worked with many businesses and individuals over the last few years, mainly helping with implementing vehicle data into their websites, forms and custom projects.</p>';
echo '<p class="clear-font-text">So, if you get stuck, just remember we are here to help, Contact us via email (enquiries@rapidcarcheck.co.uk).</p>';
echo '<div style="height:12px" aria-hidden="true" class="admin-spacer"></div>';	
	

//demo page importer..
echo '<div style="height:12px" aria-hidden="true" class="admin-spacer"></div>';
echo '<p class="backend-font-heavy-big">Import Demo Pages?</p>';
echo '<p class="clear-font-text">Click the button below to import demo pages and make setup quicker!</p>';
echo '<form id="demopage" method="POST" action="">
	<input name="demopageimport" id="demopageimport" type="hidden" value="yes">
    <div class="gen_button_sign"><button type="submit" class="demo-page-importfvd" id="demopimport">IMPORT DEMO PAGE CONTENT</button></div></form>';
echo '<div style="height:12px" aria-hidden="true" class="admin-spacer"></div>';	

//clear image cache..
echo '<div style="height:12px" aria-hidden="true" class="admin-spacer"></div>';
echo '<p class="backend-font-heavy-big">Cleaning</p>';
echo '<p class="clear-font-text">Over time vehicle image files and logs can build up, to keep things running smoothly, delete logs and locally stored images once in a while.</p>';
echo '<div style="height:1px" aria-hidden="true" class="admin-spacer"></div>';	

echo '<form id="delsearchlog" method="POST" action="">
	<input name="deletesearchlog" id="deletesearchlog" type="hidden" value="yes">
    <div class="gen_button_settings"><button type="submit" class="clear-logs-btn" id="demopimport">DELETE VEHICLE SEARCH LOG</button></div></form>';
echo '<div style="height:12px" aria-hidden="true" class="admin-spacer"></div>';	

echo '<form id="clearimagecache" method="POST" action="">
	<input name="deleteimagecache" id="deleteimagecache" type="hidden" value="yes">
    <div class="gen_button_settings"><button type="submit" class="clear-logs-btn" id="demopimport">CLEAR LOCAL IMAGE CACHE</button></div></form>';
echo '<div style="height:12px" aria-hidden="true" class="admin-spacer"></div>';	
		
	
//help and support...
echo '<div style="height:12px" aria-hidden="true" class="admin-spacer"></div>';
echo '<p class="backend-font-heavy-big">Help and Support?</p>';
echo '<p class="clear-font-text">> <a href="https://www.rapidcarcheck.co.uk/Support/PluginSetupGuide.pdf" target="_blank">PDF Setup Guide</a></p>';
echo '<p class="clear-font-text">> <a href="' . plugin_dir_url(__FILE__) . 'ShortCodeList.csv" target="_blank">Full Shortcode List With Explanation (.csv)</a>';
echo '<p class="clear-font-text">> <a href="https://youtu.be/4eonzwKmGPI" target="_blank">YouTube Video Setup Guide</a>';
if ($CurrentSupporter == 'yes'){
echo '<p class="clear-font-text">> Stuck With Something? - Email Us: enquiries@rapidcarcheck.co.uk</a>';
}else{
echo '<p class="clear-font-text">> Stuck With Something? - Email Us: <strong>[Upgrade API access to reveal]</strong></a>';	
}
$ClearAPAcc = get_admin_url( null, null, null ) . 'admin.php?page=free-vehicle-data-uk&clearapi=true';
echo '<p class="clear-font-text">> <a href="' . $ClearAPAcc . '">Deauthorize API Access (Only do this if you are having access issues)</a></strong></a>';	


}
}
?>