<?php

if (!defined('ABSPATH'))exit;
    /*
    Plugin Name: Free Vehicle Data UK
    Plugin URI:  https://www.rapidcarcheck.co.uk/
    Description: The Free Vehicle UK API Plugin lets you show UK vehicle data on your website via the Rapid Car Check API.
    Version:     1.2.7
    Author:      Rapid Car Check
    Author URI:  https://www.rapidcarcheck.co.uk/about/
    License:     GPL2

    Free Vehicle Data UK: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 2 of the License, or
    any later version.

    Free Vehicle Data UK WordPress Plugin is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Free Vehicle Data UK WordPress Plugin. If not, see https://www.gnu.org/licenses/gpl.txt.
    */
    if ( !defined('ABSPATH') ) {
        die("-1");   
    }
    
    require_once('free_vehicle_data_shortcodes.php');
    require_once('admin_area.php');
   

    add_action( 'wp_enqueue_scripts', 'free_vehicle_data_uk_plugin_assets' );
    function free_vehicle_data_uk_plugin_assets() {
	   wp_enqueue_style( 'fvdukstyle', plugin_dir_url( __FILE__ ) . 'assets/css/style.css' );
    }
	
	//PLUGIN OPTIONS [ ON PLUGIN ACTIVATION ]
	register_activation_hook( __FILE__, 'add_settings_for_fvduk' );
	function add_settings_for_fvduk(){
	
	if (get_option( 'FVDUKDisableEndPoint' ) == false){
	add_option( 'FVDUKDisableEndPoint', 'yes' );//disable endpoint until signup (avoid errors)
	}
	
	if (get_option( 'FVDUKCreditUs' ) == false){
	add_option( 'FVDUKCreditUs', 'no' );//Set credit us option
	}
	
	if (get_option( 'FVDUKCreditLink' ) == false){
	$selectone = array("https://www.rapidcarcheck.co.uk/", "https://www.rapidcarcheck.co.uk/developer-api/");	
	$kxx = array_rand($selectone);
	$vxx = $selectone[$kxx];
	add_option( 'FVDUKCreditLink', $vxx );//Set credit us option
	}	

	}	
	
?>