<?php
	print( '<div class="promo-area">
		<a target="_blank" href="https://1.envato.market/X3RGa"><img src="http://static.pantherius.com/modal-survey/preview-horizontal.jpg"></a>
		<a target="_blank" href="https://1.envato.market/0DDdL"><img src="http://static.pantherius.com/wordpress-contact-form/preview-horizontal.jpg"></a>
	</div>' );
?>


