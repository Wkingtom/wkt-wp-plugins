<?php
        if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
?>
    <li>
    <p><span class="dashicons dashicons-flag error"></span> <?php _e("Permalink is required to be turned ON at Settings > Permalinks, for WP Hide & Security Enhancer to work", 'wp-hide-security-enhancer') ?></p>
    </li>