<?php
        if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
?>

    <li>
    <p><span class="dashicons dashicons-flag error"></span> <?php _e("This plugin version can't handle MultiSite environment and may fail to provide specific features, please check with WP Hide PRO at", 'wp-hide-security-enhancer')  ?> <a target="_blank" href="https://wp-hide.com/wp-hide-pro-now-available/">WP-Hide PRO</a></p>
    </li>                            