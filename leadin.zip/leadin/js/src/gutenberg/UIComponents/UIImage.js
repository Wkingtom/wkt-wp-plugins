import { styled } from '@linaria/react';

export default styled.img`
  height: ${props => props.height};
  width: ${props => props.width};
`;
