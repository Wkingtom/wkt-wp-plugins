import { styled } from '@linaria/react';

export default styled.div`
  text-align: ${props => props.textAlign};
`;
